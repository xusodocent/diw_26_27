# Inventari de les jornades

| Id | Activitat | Descripció | Hora | Espai |
| --- | --- | --- | --- | --- |
| | | | | |
| | | | | |
| | | | | |
| | | | | |
| | | | | |
| | | | | |

## Navegació
| Entrada | Destinació | Tasca que resol |
| --- | --- | --- |
| Inici | index.html | |
| Tot el programa | programa.html | |
| Horaris | programa.html#horaris | |
| Activitats | programa.html#activitats | |
| La teua visita | informacio.html | |
