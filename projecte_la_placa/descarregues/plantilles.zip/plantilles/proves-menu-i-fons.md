# Proves de la versió ampliada

Navegador i versió:
Dispositiu real o emulació:

| Context | Acció | Esperat | Observat | Correcció | Nova prova |
| --- | --- | --- | --- | --- | --- |
| Ample | Obrir Programa | Submenú visible | | | |
| Estret | Activar Menú | Panell visible | | | |
| Estret | Escape dues vegades | Submenú i menú tancats; focus al botó | | | |
| Canvi d’amplària | Estret → ample | Navegació visible | | | |
| Sense JS | Obrir una pàgina | Enllaços visibles | | | |
| Ample i punter fi | Scroll sobre franja | Fons fix | | | |
| Moviment reduït | Scroll sobre franja | Fons normal | | | |
| Teclat | Tab i activació | Focus visible i controls operables | | | |
