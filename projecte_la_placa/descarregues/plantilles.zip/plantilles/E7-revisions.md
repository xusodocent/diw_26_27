# E7 · Revisions i entrega final

| Tipus: error, millora o comprovació | Context | Causa o motiu | Canvi | Verificació posterior |
| --- | --- | --- | --- | --- |
| | | | | |
| | | | | |
| | | | | |

## Procedència de recursos
| Recurs | Autoria/font | Permís o llicència | Canvis |
| --- | --- | --- | --- |
| | | | |

## Com obrir el projecte
Instruccions:
Resultat d’obrir el ZIP en una altra carpeta:
Limitacions pendents:

## Defensa
Tasca que mostraré:
Decisió de disseny:
Regla CSS que explicaré:
Correcció que demostraré:
