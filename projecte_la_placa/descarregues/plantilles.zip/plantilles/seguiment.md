# Registre de seguiment

Entrega:
Versió:

1. He completat:
2. Em falta o em falla:
3. El següent pas serà:

## Ajudes utilitzades
Solució, recurs o ajuda consultada:
Fitxers o fragments reutilitzats:
Canvis propis:

## Retorn i correcció
| Prioritat rebuda | Què he canviat | On es pot comprovar |
| --- | --- | --- |
| | | |
