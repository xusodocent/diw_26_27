# E2 · Disseny

## Wireframes
Inclou les tres pàgines en amplària estreta i ampla: sis esquemes en total.

## Estats de navegació
Representa el submenú obert en escriptori i el menú mòbil tancat i obert. Indica la posició del logo, el botó hamburguesa, els enllaços i el focus de teclat.

## Franja amb fons fix
Marca on apareix, quin text se superposa i quina alternativa tindrà en mòbil o amb moviment reduït.

## Guia d’estil
| Element | Valor | Justificació |
| --- | --- | --- |
| Colors | | |
| Tipografia | | |
| Espaiats | | |
| Logo i barra de navegació | | |
| Submenú i botó hamburguesa | | |
| Targeta | | |
| Enllaç i estats | | |

## Contrast
Parella de colors, relació, eina i decisió:

## Alternatives
Dues versions d’un component i justificació de l’elecció:
Comparació de l’eina de disseny amb una alternativa:

## Mockups
Inclou l’inici en dues amplàries i explica el recorregut entre pàgines.
