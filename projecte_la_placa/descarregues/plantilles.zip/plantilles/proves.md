# Registre de proves

Nom i entrega:
Navegadors i versions:
Dispositiu físic o emulació:

| Pàgina | Context o amplària | Acció | Resultat esperat | Resultat observat | Correcció | Nova prova |
| --- | --- | --- | --- | --- | --- | --- |
| | | | | | | |

## Validació
Eina i perfil:
Errors corregits:
Avisos investigats:
Limitacions pendents:

## Prova amb una persona
| Tasca | Resultat | Ajuda necessària | Observació |
| --- | --- | --- | --- |
| | | | |
