# E1 · Anàlisi i mapa

Nom:
Temàtica:
Data:

## Encàrrec
- Qui encarrega la web?
- Públic principal:
- Situació d’ús:
- Necessitats:
- Objectiu:
- Límits:

## Tres tasques
| Tasca | Recorregut | Resultat esperat |
| --- | --- | --- |
| 1 | | |
| 2 | | |
| 3 | | |

## Anàlisi d’una interfície
URL i data:
Captures i funció dels elements:
Decisió que mantindria:
Decisió que canviaria:

## Mapa i inventari
Insereix el mapa de les tres pàgines i indica continguts i fonts.
